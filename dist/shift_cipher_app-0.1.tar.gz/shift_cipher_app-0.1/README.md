# Shift Cipher App

Ứng dụng Shift Cipher cho phép mã hóa và giải mã văn bản bằng cách sử dụng kỹ thuật dịch chuyển (Shift Cipher).

## Cài đặt

```bash
pip install -e .
## Chạy ứng dụng
python app.py
